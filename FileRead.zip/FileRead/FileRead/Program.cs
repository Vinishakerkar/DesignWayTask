﻿using System;
using System.Collections.Generic;
using FileRead.Common;
using FileRead.Save;


namespace FileRead
{
    class program
    {
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Enter the Numbers to be sorted and the formating (XML,JSON,TEXT)");
                string input = Console.ReadLine();
                string[] inputs = input.Split(" ");
                if (inputs == null || inputs.Length != 2)
                {
                    Console.WriteLine("Please enter correct Input");
                    return;
                }

                ISave saveFile;
                switch (inputs[1].Trim().ToLower())
                {
                    case FileExtensions.XML:
                        saveFile = new XML();
                        break;
                    case FileExtensions.JSON:
                        saveFile = new JSon();
                        break;
                    default:
                        saveFile = new Text();
                        break;
                }

                saveFile.SaveFile(inputs[0].Trim());
            }
        }

    }
}

