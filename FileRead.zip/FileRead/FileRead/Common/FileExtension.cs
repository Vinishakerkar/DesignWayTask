﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileRead.Common;

namespace FileRead.Common
{
    public static class FileExtensions
    {
        public const string TEXT = "txt";
        public const string XML = "xml";
        public const string JSON = "json";
    }
}
