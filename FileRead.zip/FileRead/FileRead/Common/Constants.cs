﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileRead.Common
{
    public static class Constants
    {
        public static string FILE_NAME = "Output";
    }
}
