﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileRead.Common;

namespace FileRead.Save
{
    public class Text : ISave
    {
        public async Task SaveFile(string numbers)
        {
            try
            {
                var numberList = HelperMethods.FormatNumbers(numbers);
                if (numberList != null)
                {
                    string filePath = HelperMethods.GetFilePath(Constants.FILE_NAME, FileExtensions.TEXT);
                    await File.WriteAllTextAsync(filePath, string.Join(",", numberList.ToArray()));
                    HelperMethods.DisplaySuccessMessage(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
        }
    }
}
