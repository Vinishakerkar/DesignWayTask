﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileRead.Common;
using System.Text.Json;

namespace FileRead.Save
{
     class JSon: ISave 
    {
        public async Task SaveFile(string numbers)
        {
            try
            {
                var numberList = HelperMethods.FormatNumbers(numbers);
                if (numberList != null)
                {
                    var jsonList = numberList.Select(m => new { Id = m.ToString() }).ToList();
                    string json = JsonSerializer.Serialize(jsonList);

                    string filePath = HelperMethods.GetFilePath(Constants.FILE_NAME, FileExtensions.JSON);
                    await File.WriteAllTextAsync(filePath, json);
                    HelperMethods.DisplaySuccessMessage(filePath);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"{ex.Message}");
            }
        }
    }
}
