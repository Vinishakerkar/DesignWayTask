﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileRead.Save
{
    public interface ISave
    {
        public Task SaveFile(string numbers);
    }
}
